import App from "./App";

App();
